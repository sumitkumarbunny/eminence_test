<?php
?>
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap" />
            </svg>
            <?php
            if (isset($_SESSION["AUTH"])) {
                echo '<span class="fs-4">' . $_SESSION["NAME"] . ' Blogs';
            } else {
                echo '<span class="fs-4">All Blogs</span>';
            }
            ?>
        </a>

        <?php
        if (isset($_SESSION["AUTH"])) {
            echo '<a href="login/login.php?q=logout"><button type="button" class="btn btn-danger  me-2">Logout</button></a>';
            echo '<a href="add_blog.php"><button type="button" class="btn btn-primary  me-2">Add Blog</button></a>';
        } else {
            echo '<a href="login/login.php" ><button type="button" class="btn btn-primary  me-2">Login</button></a>';
        }
        ?>
    </header>
</div>
<div class="b-example-divider"></div>