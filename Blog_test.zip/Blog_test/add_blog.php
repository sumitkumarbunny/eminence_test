<?php

include 'inc/frontend_helpers.php';
if (!isset($_SESSION["AUTH"])) {
    header('Location: login/login.php');
    $user_id = $_SESSION["ID"];
}
$GLOBALS['TYPE'] = 0;
if (isset($_POST["submit"])) {
    $title = $_POST['title'];
    $description = $_POST['description'];

    $image = time() . '_' . $_FILES["image"]["name"];
    $tempname = $_FILES["image"]["tmp_name"];
    $folder = "images/" . $image;
    move_uploaded_file($tempname, $folder);

    # Insert into the database
    $query = "INSERT INTO `blogs` (`id`,`student_id`, `title`, `description`, `image`, `created_at`) 
    VALUES (NULL, '$student_id', '$title', '$description', '$image', current_timestamp());";
    if (mysqli_query($conn, $query)) {
        echo "New Blog created successfully !";
    } else {
        echo "Error inserting Blog: " . $conn->error;
    }
}

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Blogs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <?php include 'inc/header.php'; ?>


    <div class="container">
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Blog Details</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <form method="post" action="" enctype="multipart/form-data">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" class="form-control" id="title" name="title" placeholder="Title">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="image">Image</label>
                                        <input type="file" class="form-control" id="image" name="image">

                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Descriptions</label>
                                        <textarea class="form-control" name="description" id="description" cols="30" rows="10"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-success" name="submit">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

</body>

</html>