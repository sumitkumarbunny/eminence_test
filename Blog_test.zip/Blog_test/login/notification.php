<script>
function showPageNotification(type = "DEFAULT", message = "", autoHide = true) {
    if (type.toUpperCase() == "SUCCESS") {
        $("#notification.alert").removeClass("alert-warning alert-danger alert-info").addClass("alert-success")
            .fadeIn();
    } else if (type.toUpperCase() == "INFO") {
        $("#notification.alert").removeClass("alert-warning alert-danger alert-success").addClass("alert-info")
            .fadeIn();
    } else if (type.toUpperCase() == "WARNING") {
        $("#notification.alert").removeClass("alert-success alert-danger alert-info").addClass("alert-warning")
            .fadeIn();
    } else if (type.toUpperCase() == "ERROR") {
        $("#notification.alert").removeClass("alert-warning alert-success alert-info").addClass("alert-danger")
            .fadeIn();
    } else if (type.toUpperCase() == "DEFAULT") {
        //$("#notification.alert").fadeOut(2000);
        $("#notification.alert").hide();
    }
    $("#notification.alert .alert-text").html(message);
    if (autoHide) {
        setTimeout(function() {
            showPageNotification("DEFAULT", message, null)
        }, 2000);
    }
}
</script>
<style>
#notification {
    display: none;
}

#notification .alert-cross {
    cursor: pointer;
}
</style>
<div class="clearfix"><br /></div>
<div class="container">
    <div class="alert alert-info small position-fixed" id="notification" role="alert">
        <span class="alert-text"></span>
        <div class="alert-cross float-right font-weight-bold pl-2" onclick="$(this).parent().hide()">&times;</div>
    </div>
</div>
<div class="clearfix"><br /><br /></div>