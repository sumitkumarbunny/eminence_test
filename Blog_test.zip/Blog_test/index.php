<?php
include 'inc/frontend_helpers.php';
$GLOBALS['TYPE'] = 0;

if (isset($_SESSION["AUTH"])) {
    $user_id = $_SESSION["ID"];
    $sql = "SELECT * FROM blogs WHERE `student_id` = $user_id";
} else {
    $sql = "SELECT * FROM blogs";
}
$result = $conn->query($sql);


?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Blogs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <?php include 'inc/header.php'; ?>
    <div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <?php
            if ($result->num_rows > 0) {
                // output data of each row
                while ($row = $result->fetch_assoc()) {
            ?>

                    <div class="col">
                        <div class="card shadow-sm">
                            <img src="<?php echo 'images/' . $row['image']; ?>" alt="">
                            <div class="card-body">
                                <h1 class="fw-light"><?php echo $row['title']; ?></h1>
                                <p class="card-text"><?php echo $row['description']; ?></p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-body-secondary"><?php echo timeAgo($row['created_at']); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo "0 results";
            }
            ?>
        </div>
    </div>
</body>

</html>